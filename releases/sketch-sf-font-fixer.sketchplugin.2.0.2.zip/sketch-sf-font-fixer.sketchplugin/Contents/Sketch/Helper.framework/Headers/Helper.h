//
//  Helper.h
//  Helper
//
//  Created by Kyle Hickinson on 2016-08-21.
//  Copyright © 2016 Kyle Hickinson. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for Helper.
FOUNDATION_EXPORT double HelperVersionNumber;

//! Project version string for Helper.
FOUNDATION_EXPORT const unsigned char HelperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Helper/PublicHeader.h>


